/*
 * Copyright (c) 2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uart2echo.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"


//State variables declaration
//enum RED_LED_STATEs{
//    LED_START,
//    LED_ON,
//    LED_OFF
//} RED_LED_STATE;

//enum RED_LED_STATEs {LED_START, LED_S0, LED_S1, LED_ON, LED_OFF} RED_LED_STATE; // Define the possible states

//void controlLED(char input)
//{
//    bytesRead = 0;
//    bytesWritten = 0;
//    switch (RED_LED_STATE)      // Transitions
//            {
//                case LED_START:     // Check if first char is an 'o'
//                    if (input == 'o' || input == 'O')
//                    {
//                        RED_LED_STATE = LED_S0;
//                    }
//                    break;
//                case LED_S0:        // Check if second char is a 'n' of 'f'
//                    if (input == 'n' || input == 'N')
//                    {
//                        RED_LED_STATE = LED_ON;
//                    }
//                    else if (input == 'f' || input == 'F')
//                    {
//                        RED_LED_STATE = LED_S1;
//                    }
//                    break;
//                case LED_S1:        // Check if third char is an 'f'
//                    if (input == 'f' || input == 'F')
//                    {
//                        RED_LED_STATE = LED_OFF;
//                    }
//                    break;
//                case LED_ON:        // Reset to start state
//                case LED_OFF:       // Reset to start state
//                default:            // Set to start state
//                    RED_LED_STATE = LED_START;
//                    break;
//            }
//
//            switch (RED_LED_STATE)  // State actions
//            {
//                case LED_START:                                         // Initial input action
//                    //UART_read(uart, &input, 1);                         // Get first char from input
//                    //UART_write(uart, &input, 1);                        // Display the input
//                   UART2_read(uart,  &input, sizeof(input), &bytesRead);
//                   UART2_write(uart, &input, sizeof(input), &bytesWritten);
//                    break;
//                case LED_S0:                                            // Second input action
//                    UART2_read(uart,  &input, sizeof(input), &bytesRead);
//                    UART2_write(uart, &input, sizeof(input), &bytesWritten);                                                   // Display the input
//                    break;
//                case LED_S1:                                            // Third input action
//                    UART2_read(uart,  &input, sizeof(input), &bytesRead);
//                    UART2_write(uart, &input, sizeof(input), &bytesWritten);                         // Get third char from input
//                                           // Display the input
//                    break;
//                case LED_ON:                                            // Turn on led action
//                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn red led on
//                    break;
//                case LED_OFF:                                           // Turn off led action
//                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); // Turn red led off
//                    break;
//                default:
//                    break;
//            }
//
//    /*switch(RED_LED_STATE)
//    {
//        case LED_START:
//            if(input =='o'||input=='O')
//            {
//                //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
//                RED_LED_STATE = LED_OFF;
//            }
//            break;
//        case LED_ON:
//            if(input == 'n'|| input=='N')
//            {
//              RED_LED_STATE = LED_ON;
//            }
//            //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
//            break;
//        case LED_OFF:
//            if(input =='f'||input=='F')
//            {
//               RED_LED_STATE = LED_OFF;
//                //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
//            }
//            break;
//        default:
//            RED_LED_STATE = LED_START;
//            break;
//    }
//    //STATE ACTION
//       switch(RED_LED_STATE)
//       {
//           case LED_OFF:
//               GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
//               break;
//           case LED_ON:
//               GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
//               break;
//           default:
//               GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
//               break;
//       }*/
//
//    //This block works
//     /* if (input == 'n' ||input == 'N')
//      {
//          GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
//      }
//      else if (input == 'f'||input == 'F')
//       {
//          GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
//       }*/
//}
/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char input;
    unsigned char state = 0;
    const char echoPrompt[] = "ON/OFF LED PROGRAM\r\n";

    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status     = UART2_STATUS_SUCCESS;

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART where the default read and write mode is BLOCKING */
    //default behavior when mode is not stated explicitly
    UART2_Params_init(&uartParams);

    //modes of operation
    uartParams.writeMode = UART2_Mode_BLOCKING;
    uartParams.readMode = UART2_Mode_BLOCKING;
    uartParams.readReturnMode = UART2_ReadReturnMode_FULL;//mode behavior
    uartParams.baudRate = 115200;//transmission speed

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL)
    {
        /* UART2_open() failed */
        while (1) {}
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    enum RED_LED_STATES {
        LED_START,
       LED_INITIAL_STATE,
        LED_SECONDCHAR,
        LED_THIRDCHAR,
        LED_SECOND_F_CHAR,
        RED_LED_ON,
        RED_LED_OFF
    } RED_LED_STATE; // Define the possible states

    RED_LED_STATE = LED_INITIAL_STATE;

    /* Loop forever echoing */
    while (1)
    {
        bytesRead = 0;
        bytesWritten = 0;

        ///////////////////////////STATE TRANSITIONS///////////////////////////////////
        switch (RED_LED_STATE)
        {
            case LED_START:
                RED_LED_STATE = LED_INITIAL_STATE;
                break;

            case LED_INITIAL_STATE:     // Checking for 'o' or 'O'
                if (input == 'o' || input == 'O')
                {
                    RED_LED_STATE = LED_SECONDCHAR;
                }
                break;

            case LED_SECONDCHAR:        // Checking for second character 'n' or 'f'
                RED_LED_STATE = (input == 'n' || input == 'N')? RED_LED_ON: LED_THIRDCHAR;
                break;

            case LED_THIRDCHAR:        // third character check for an 'f' or 'F'
                if (input == 'f' || input == 'F')
                {
                    RED_LED_STATE = LED_SECOND_F_CHAR;
                }

                //check for second 'f' character
            case LED_SECOND_F_CHAR:
                if(input == 'f' || input == 'F')
                {
                    RED_LED_STATE = RED_LED_OFF;
                }
                break;

            //REVERTING TO THE INITIAL DEFAULT STATE
            case RED_LED_ON:
            case RED_LED_OFF:

            default:
                RED_LED_STATE = LED_START;
                break;
        }

        /********************STATE ACTIONS**************************************/
        switch (RED_LED_STATE)
        {

        //Defining read and write actions in the initial state
            case LED_INITIAL_STATE:
                UART2_read(uart, &input, 1, &bytesRead);
                UART2_write(uart, &input, 1, &bytesWritten);
                break;

        //Reading and writing second character
            case LED_SECONDCHAR:
                UART2_read(uart, &input, 1, &bytesRead);
                UART2_write(uart, &input, 1, &bytesWritten);
                break;

        //Reading and writing third and fourth characters 'ff'
            case LED_THIRDCHAR:
            case LED_SECOND_F_CHAR:
                UART2_read(uart, &input, 1, &bytesRead);
                UART2_write(uart, &input, 1, &bytesWritten);
                break;

        //Defining the RED_LED_ON state action -- turn on the red led
            case RED_LED_ON:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                break;

        //Defining the RED_LED_OFF state action -- turn off the red led
            case RED_LED_OFF:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                break;

            default://do nothing
                break;
        }
    }
}
